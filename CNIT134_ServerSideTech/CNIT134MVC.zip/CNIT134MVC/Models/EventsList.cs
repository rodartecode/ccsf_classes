﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CNIT134MVC.Models
{
    public class EventsList
    {
        public IList<Event> Events { get; set; }
    }
}
