﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

/*
 Jesse E Rodarte
 02/05/2020
 CNIT134
 Homework 2: Console Application
     */

namespace consolehw
{
    class Program
    {
        static void Main(string[] args)
        {
            string names = @"names.txt";

            Console.Write("Enter a name to add to the file: ");
            string newName = Console.ReadLine();

            using (StreamWriter sw = File.AppendText(names))
            {
                sw.WriteLine(newName);
                sw.Close();
            }
            int participants = 0;
            using (StreamReader sr = File.OpenText(names)) 
            { 
                string lines = ""; 
                while ((lines = sr.ReadLine()) != null) 
                { 
                    Console.WriteLine(lines);
                    participants++;
                } 
            }
            Console.WriteLine($"There are {participants} new participants in the seminar!");
            Console.ReadKey();
        }
    }
}
